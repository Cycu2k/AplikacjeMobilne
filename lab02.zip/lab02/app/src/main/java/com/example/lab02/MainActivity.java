package com.example.lab02;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Panel panel;
    Paint bg1 = new Paint();
    Paint bg2 = new Paint();

    protected void onCreate(Bundle savedInstaceState){
        super.onCreate(savedInstaceState);
        requestWindowFeature(Window.FEATURE_CONTEXT_MENU);
        setContentView(panel = new Panel(this));
    }
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();
        if(id == R.id.tworca){
            Toast toast = Toast.makeText(getApplicationContext(),"Twórca: Cyprian Górny",Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER,0,0);
            toast.show();
            return true;
        }
        if(id == R.id.exit){
            finish();
            return true;
        }
        if(id == R.id.color1){
            bg1.setColor(Color.BLACK);
            bg2.setColor(Color.WHITE);
            panel.postInvalidate();
            return true;
        }
        if(id == R.id.color2){
            bg1.setColor(Color.BLUE);
            bg2.setColor(Color.RED);
            panel.postInvalidate();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    class Panel extends View{
        public Panel(Context context){
            super(context);
            bg1.setColor(Color.WHITE);
            bg2.setColor(Color.BLACK);
        }

        public void onDraw(Canvas canvas){
            canvas.drawColor(Color.LTGRAY);
            float width = panel.getWidth();
            float height = panel.getHeight();

            float minSize = Math.min(width, height);

            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if ((i+j)%2==0) {
                        canvas.drawRect(i*minSize/8, j*minSize/8, (i+1)*minSize/8, (j+1)*minSize/8, bg1);
                    } else {
                        canvas.drawRect(i*minSize/8, j*minSize/8, (i+1)*minSize/8, (j+1)*minSize/8, bg2);
                    }
                }
            }
        }
    }
}
