package com.example.hakowanieplikownasa;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    TextView titleText, descriptionText;
    Button buttonDays;

    String dateString = "";

    Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.nasa.gov/planetary/").addConverterFactory(GsonConverterFactory.create()).build();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // API KEY: GEwUI28ZZ2K9klz1o3J22Q5Dh6P6eKkPWxfwtZSm
        //          GEwUI28ZZ2K9klz1o3J22Q5Dh6P6eKkPWxfwtZSm
        // EMAIL: rod29984@kisoq.com
        // ACCOUNT ID: 9de4caed-e341-43e1-998a-1fc40ff180f0
        //

        // http://klasy.itmargen.com/Rok%202024_2025/5TR/AM/Pobieranie%20danych%20z%20Internetu/Zadanie2.txt

        // GET https://api.nasa.gov/planetary/apod

        imageView = findViewById(R.id.imageView);
        titleText = findViewById(R.id.titleText);
        descriptionText = findViewById(R.id.descriptionText);
        buttonDays = findViewById(R.id.buttonDays);

        buttonDays.setOnClickListener(view -> {
            DatePicker picker = new DatePickerDialog(view.getContext()).getDatePicker();

            dateString = picker.getYear() + "-" + (picker.getMonth()+1) + "-" + (picker.getDayOfMonth()/10>0?picker.getDayOfMonth():"0"+picker.getDayOfMonth());
            System.out.println("\r\nDate: " + dateString + "\r\n\r\n");
        });




    }

    public void fetchData() {
        JsonInterface jsonInterface = retrofit.create(JsonInterface.class);

        Call<List<NasaData>> listNasa = jsonInterface.getNasaData();

        System.out.println("\r\n///// Czytanie danych nasa /////\r\n");

        listNasa.enqueue(new Callback<List<NasaData>>() {
            @Override
            public void onResponse(Call<List<NasaData>> call, Response<List<NasaData>> response) {
                if (!response.isSuccessful()) {
                    System.out.println("Cos poszlo nie tak w czytaniu tego tegos");
                    return;
                }

                List<NasaData> nasas = response.body();

                for (NasaData data : nasas) {
                    titleText.setText(data.title);
                    descriptionText.setText(data.description);
                    // set url for image view tez tutaj jakos
                }

                System.out.println("Przeczytano ‼️‼️‼️‼️");
            }

            @Override
            public void onFailure(Call<List<NasaData>> call, Throwable t) {
                System.out.println("Blad error blad error blad error blad error");
                System.out.println(call);
                System.out.println(t);
            }
        });

    }
}

interface JsonInterface {
    @GET("apod")
    Call<List<NasaData>> getNasaData();
}

class NasaData {
    @SerializedName("title")
    String title;
    @SerializedName("explanation")
    String description;
    @SerializedName("url")
    String photoUrl;
}