package com.example.Cyprian_lab01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button)this.findViewById(R.id.button);
        button.setOnClickListener(v ->{
            button.setText("Cyprian Górny klasa 4Tr",TextView.BufferType.NORMAL);
            Toast.makeText(this,"Cyprian Górny klasa 4Tr",Toast.LENGTH_SHORT).show();
        });

    }

}

