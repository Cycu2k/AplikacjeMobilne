package com.example.verycoolrandomsortingview;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    ExecutorService executor = Executors.newFixedThreadPool(10);
    Boolean isProcessing = false;
    Random r = new Random();
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        SortingView sortingView = findViewById(R.id.sortingView);

        Button buttonStart = findViewById(R.id.buttonSort);

        TextView inputNumber = findViewById(R.id.inputNumber);

        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(ProgressBar.INVISIBLE);

        //myPaint.setStrokeWidth(50);

        buttonStart.setOnClickListener(e->{
            // start executor service or somthmohrggggggggggggggggg
            if (isProcessing == true) {
                Toast.makeText(this, "You can't start another sorting when the current one is still ongoing!", Toast.LENGTH_LONG).show();
                return;
            }
            isProcessing = true;

            int howManyRandoms = Integer.parseInt(inputNumber.getText().toString());
            float[] randomNumbers = new float[howManyRandoms];

            for (int i = 0; i < howManyRandoms; i++) {
                randomNumbers[i] = r.nextFloat(); // gens floats from 0 to 1 for ez line height making
            }

            Toast.makeText(this, "Generated numbers, starting sort!", Toast.LENGTH_LONG).show();

            progressBar.setVisibility(ProgressBar.VISIBLE);
            progressBar.setProgress(0, false);

            executor.execute(() -> {
                // all the sorting here
                // and then pass the sorted array to the sortingview at every step
                // wait .02 at every step
                for (int i = 0; i < randomNumbers.length-1; i++) {
                    for (int j = 0; j < randomNumbers.length-1; j++) {
                        if (randomNumbers[j] < randomNumbers[j+1]) {
                            float swapVar = randomNumbers[j+1];
                            randomNumbers[j+1] = randomNumbers[j];
                            randomNumbers[j] = swapVar;

                            // sleep only when something moves
                            try {
                                Thread.sleep(50);
                            } catch (InterruptedException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                        // send the array to sortingview
                        sortingView.drawArray(randomNumbers);

                    }

                    // update progress bar
                    float progressF = (float)(i+2)/howManyRandoms * 100;
                    System.out.println("i: " + (i+2));
                    System.out.println("how many randoms: " + howManyRandoms);
                    System.out.println("Progress float: " + progressF);

                    int progress = (int) progressF;
                    progressBar.setProgress(progress, true);
                    System.out.println("Progress: " + progress);

                    publishProgress(progress);
                }


                isProcessing = false;
            });
        });
    }

    void publishProgress(int progress) {
        if (progressBar == null) {
            return;
        }

        runOnUiThread(()->{
            progressBar.setProgress(progress);
        });
    }
}