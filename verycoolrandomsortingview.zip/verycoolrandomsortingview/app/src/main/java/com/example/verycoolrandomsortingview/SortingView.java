package com.example.verycoolrandomsortingview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.Arrays;

public class SortingView extends View {
    Canvas canvas = new Canvas();
    Paint p = new Paint();

    float[] randomNumbers;

    void init() {

    }

    public SortingView(Context context) {
        super(context);
        init();
    }

    public SortingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SortingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (randomNumbers == null) {
            return;
        }

        float[] array = randomNumbers;

        System.out.println("Random numbers:");
        System.out.println(Arrays.toString(array));

        // line width = array.length / getWidth()
        // start drawing at x 0 and then move right by line width

        // to nie musi sie rekalkulowac co liczbe
        float lineWidth = (float) getWidth() / array.length;
        p.setStrokeWidth(lineWidth);

        canvas.drawColor(Color.WHITE, PorterDuff.Mode.OVERLAY);

        float drawAtX = lineWidth/2;

        for (int i = 0; i < array.length; i++) {
            // calc line height by
            // getHeight() * array[i] (the numbers are floats from 0 to 1 so its automatically percentages)

            // calc line width by
            // randomNumbers / getWidth()

            // start at x 0 and add line width
            // draw from y getHeight() to lineHeight

            //canvas.drawLine();

            float lineHeight = (float) getHeight() * array[i];

            System.out.println("Line width: " + lineWidth);
            System.out.println("Line height: " + lineHeight);

            canvas.drawLine(drawAtX, getHeight(), drawAtX, lineHeight, p);
            drawAtX += lineWidth;
        }
    }


    //
    void drawArray(float[] array) {
        randomNumbers = array;

        this.invalidate();
    }
}
