package com.example.zarzadzanielistazadan;

public class ListElement {
    String name;
    String desc;

    ListElement(String inName, String inDesc) {
        name = inName;
        desc = inDesc;
    }
}
