package com.example.zarzadzanielistazadan;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton fab;
    RecyclerView recycler;

    public static CustomAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        fab = findViewById(R.id.fab);
        recycler = findViewById(R.id.recycler);

        Intent gotoAddActivity = new Intent(this, AddItemFabMenu.class);

        fab.setOnClickListener(view -> {
            // go to add item fab menu
            System.out.println("\r\nGoing to fab add item menu\r\n");
            startActivityForResult(gotoAddActivity, 0);
        });

        // todo : this thing right over here, and fast

        if (adapter == null) adapter = new CustomAdapter(this, DataStuff.tasks);

        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);


        // in recycler list:
        // on element clicked:
        //      open edit item menu (Intent i startActivityForResult() )
        //      fill in data
        //      on save, quit the menu and edit the data in the list the adapter uses


    }


}

class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private LayoutInflater inflater;
    private Context context;

    ArrayList<ListElement> arrayList;
    public CustomAdapter(Context context, ArrayList<ListElement> arrayList) {
        inflater = LayoutInflater.from(context);
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.listitem, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.labelName.setText(arrayList.get(position).name);
        holder.labelDesc.setText(arrayList.get(position).desc);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView labelName;
        TextView labelDesc;

        public MyViewHolder(View itemView) {
            super(itemView);
            labelName = itemView.findViewById(R.id.labelName);
            labelDesc = itemView.findViewById(R.id.labelDesc);

            itemView.setOnClickListener(view -> {
                // go to edit item tyhigny here maybe
                System.out.println("Clicked ");
                int position = getAdapterPosition();
                Intent gotoEditItemActivity = new Intent(context, EditItemMenu.class);
                gotoEditItemActivity.putExtra("position", position);

                context.startActivity(gotoEditItemActivity);

            });
        }
    }
}