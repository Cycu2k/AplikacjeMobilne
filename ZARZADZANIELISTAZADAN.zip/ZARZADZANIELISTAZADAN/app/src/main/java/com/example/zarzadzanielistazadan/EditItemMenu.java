package com.example.zarzadzanielistazadan;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditItemMenu extends AppCompatActivity {
    EditText inputName, inputDesc;
    Button buttonSave;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.additemfabmenu);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // get id from extra in intent
        int position = getIntent().getIntExtra("position", 0);

        inputName = findViewById(R.id.inputName);
        inputDesc = findViewById(R.id.inputDesc);

        inputName.setText(DataStuff.tasks.get(position).name);
        inputDesc.setText(DataStuff.tasks.get(position).desc);

        buttonSave = findViewById(R.id.buttonSave);

        buttonSave.setOnClickListener(view -> {

            // edit the stuff in datastuff.tasks
            DataStuff.tasks.get(position).name = inputName.getText().toString();
            DataStuff.tasks.get(position).desc = inputDesc.getText().toString();

            MainActivity.adapter.notifyDataSetChanged();

            finish();
        });

    }
}
