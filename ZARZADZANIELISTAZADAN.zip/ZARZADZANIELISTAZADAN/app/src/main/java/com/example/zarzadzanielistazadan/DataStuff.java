package com.example.zarzadzanielistazadan;

import java.util.ArrayList;

public class DataStuff {
    public static ArrayList<ListElement> tasks = new ArrayList<ListElement>();
}