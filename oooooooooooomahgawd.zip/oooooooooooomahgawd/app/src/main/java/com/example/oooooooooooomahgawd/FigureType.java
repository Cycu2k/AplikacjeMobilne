package com.example.oooooooooooomahgawd;

public enum FigureType {
    Lines,
    Ellipses,
    Rectangles
}
