package com.example.oooooooooooomahgawd;

public enum CreationType {
    Create,
    Clear
}
