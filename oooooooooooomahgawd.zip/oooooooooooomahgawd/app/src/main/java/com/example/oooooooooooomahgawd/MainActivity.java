package com.example.oooooooooooomahgawd;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {



    kreatoromg creator;
    Button buttonCreate;
    Button buttonClear;
    Button buttonLines;
    Button buttonEllipses;
    Button buttonRectangles;

    TextView labelCreationType;
    TextView labelFigureType;

    public static CreationType creationType = CreationType.Create;
    public static FigureType figureType = FigureType.Lines;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        creator = findViewById(R.id.creatorView);

        buttonCreate = findViewById(R.id.buttonCreate);
        buttonClear = findViewById((R.id.buttonClear));

        buttonLines = findViewById(R.id.buttonLines);
        buttonEllipses = findViewById(R.id.buttonEllipses);
        buttonRectangles = findViewById(R.id.buttonRectangles);

        //choose creation mode
        //clicking on figure buttons draws or clears them
        //create/clear buttons is just for choosing modes
        buttonCreate.setOnClickListener((click)->{
            creationType = CreationType.Create;
            // TUTAJ TEZ WYWOLAJ METODE Z kreatoromg KTORA BEDZIE RYSOWAC NA PODSTAWIE creationType i figureType
            // mozesz przekazac po prostu creationtype od razu do metody 😢😢😢😢😢😢😢😹😹😹

            updateCreationTypeText();
        });
        buttonClear.setOnClickListener((click)->{
            creationType = CreationType.Clear;

            updateCreationTypeText();
        });

        buttonLines.setOnClickListener((click)->{
            figureType = FigureType.Lines;
            updateFigureTypeText();

            handleDraw();
        });
        buttonEllipses.setOnClickListener((click)->{
            figureType = FigureType.Ellipses;
            updateFigureTypeText();

            handleDraw();
        });
        buttonRectangles.setOnClickListener((click)->{
            figureType = FigureType.Rectangles;
            updateFigureTypeText();

            handleDraw();
        });

        labelCreationType = findViewById(R.id.labelCreationType);
        labelFigureType = findViewById(R.id.labelFigureType);
        updateCreationTypeText();
        updateFigureTypeText();
    }

    void handleDraw() {
        creator.DrawFigures();
    }

    void updateCreationTypeText() {
        labelCreationType.setText("CreationType: " + creationType.toString());
    }
    void updateFigureTypeText() {
        labelFigureType.setText("FigureType: " + figureType.toString());
    }
}