package com.example.oooooooooooomahgawd;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Random;

public class kreatoromg extends View {
    Bitmap linesBitmap = Bitmap.createBitmap(1000, 1000, Bitmap.Config.ARGB_8888), ellipsesBitmap = Bitmap.createBitmap(1000, 1000, Bitmap.Config.ARGB_8888), rectanglesBitmap = Bitmap.createBitmap(1000, 1000, Bitmap.Config.ARGB_8888);
    Canvas canvasLines = new Canvas(linesBitmap), canvasEllipses = new Canvas(ellipsesBitmap), canvasRectangles = new Canvas(rectanglesBitmap);

    void setupStuff() {
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setAntiAlias(true);
    }

    public kreatoromg(Context context) {
        super(context);
        setupStuff();
    }

    public kreatoromg(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setupStuff();
    }

    public kreatoromg(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setupStuff();
    }

    Paint paint = new Paint();

    Random r = new Random();

    int drawMult = 2;
    public void randomPaint() {
        paint.setARGB(255, r.nextInt(255), r.nextInt(255), r.nextInt(255));
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);

        System.out.println("Ondraw is called 😱😱😱😱😱😱😱");

        canvas.drawColor(Color.TRANSPARENT);

        int width = getWidth(), height = getHeight();

        if (MainActivity.creationType == CreationType.Create) {
            // DRAWING MODE
            switch(MainActivity.figureType) {
                case Lines:
                    for (int i = 0; i < drawMult; i++) {
                        randomPaint();
                        canvasLines.drawLine(r.nextInt(width), r.nextInt(height), r.nextInt(width), r.nextInt(height), paint);
                    }

                    break;

                case Ellipses:
                    for (int i = 0; i < drawMult; i++) {
                        randomPaint();
                        canvasEllipses.drawOval(r.nextInt(width), r.nextInt(height), r.nextInt(width), r.nextInt(height), paint);
                    }

                    break;

                case Rectangles:
                    for (int i = 0; i < drawMult; i++) {
                        randomPaint();
                        canvasRectangles.drawRect(r.nextInt(width), r.nextInt(height), r.nextInt(width), r.nextInt(height), paint);
                    }

                    break;
            }
        } else {
            // CLEARING MODE
            switch(MainActivity.figureType) {
                case Lines:
                    canvasLines.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                    break;

                case Ellipses:
                    canvasEllipses.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                    break;

                case Rectangles:
                    canvasRectangles.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                    break;
            }
        }

        canvas.drawBitmap(linesBitmap, 0, 0, null);
        canvas.drawBitmap(ellipsesBitmap, 0, 0, null);
        canvas.drawBitmap(rectanglesBitmap, 0, 0, null);
    }

    /// metodhy do zadaniaaaaaaaaaaa
    public void DrawFigures() {
        System.out.println("DrawFigures is called 😱😱😱😱😱");

        //Bitmap bitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);

        //canvas.drawBitmap(bitmap, getMatrix(), paint);
        //canvas.drawLine(r.nextInt(), r.nextInt(), r.nextInt(), r.nextInt(), paint);

        this.invalidate();

    }
}
