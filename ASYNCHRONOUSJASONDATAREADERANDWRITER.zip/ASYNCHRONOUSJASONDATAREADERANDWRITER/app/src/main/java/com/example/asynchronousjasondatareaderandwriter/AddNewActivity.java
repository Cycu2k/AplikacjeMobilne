package com.example.asynchronousjasondatareaderandwriter;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddNewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_new);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button buttonConfirmAddNew = findViewById(R.id.buttonConfirmAddNew);

        EditText inputProductName = findViewById(R.id.inputProductName);
        EditText inputPrice = findViewById(R.id.inputPrice);
        EditText inputDescription = findViewById(R.id.inputDescription);


        buttonConfirmAddNew.setOnClickListener(view->{
            String productName = inputProductName.getText().toString();
            String price = inputPrice.getText().toString();
            String description = inputDescription.getText().toString();

            // dodaj do listy

            DataList.addElement(productName, price, description);

            // reset danych przed wyjsciem

            inputProductName.setText("");
            inputPrice.setText("");
            inputDescription.setText("");

            //  wyjdz z activity tego

            finish();
        });

    }
}