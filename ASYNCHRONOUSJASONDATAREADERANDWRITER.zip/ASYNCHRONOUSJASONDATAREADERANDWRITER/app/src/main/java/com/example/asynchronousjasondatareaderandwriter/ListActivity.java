package com.example.asynchronousjasondatareaderandwriter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import java.util.List;

public class ListActivity extends AppCompatActivity {
    //ArrayAdapter<ListElement> adapter;
    static LinearLayout buttonLayout;
    static Context myContext;

    static UpdateLoopTask myTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //ListView list = findViewById(android.R.id.list);

        //adapter = new ArrayAdapter<>(this, R.layout.listrow, DataList.listElements);
        //list.setAdapter(adapter);

        //list.addTouchables();

        //(new RefreshListTask()).execute();

        System.out.println("Updating context");
        myContext = this;
        System.out.println("Context: " + myContext.toString());

        buttonLayout = findViewById(R.id.buttonLayout);
        System.out.println("Button layout: " + buttonLayout.toString());

        //updateListWithData();

        // todo here:
        // start thread
        // loop 5 seconds
        // updateListWithData()

        if (myTask == null) {
            new UpdateLoopTask().execute();
        }
    }

    public class UpdateLoopTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void...arg) {
            while(true) {
                try {
                    Thread.sleep(5000);
                } catch(InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }

                ListActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        updateListWithData();
                    }
                });
            }
        }
    }

    /*private class RefreshListTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... arg0) {
            try {

                do {
                    adapter.notifyDataSetChanged();
                    Thread.sleep(5000);
                } while(true);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return null;
        }

        protected Void onProgressUpdate(Integer... progress) {
            return null;
        }

        protected Void onPostExecute(Long result) {
            return null;
        }


    }*/

    public static void updateListWithData() {
        System.out.println("Button layout in funcL: " + buttonLayout.toString());
        buttonLayout.removeAllViews();

        int buttonIndex = 0;
        for(ListElement listElement : DataList.listElements) {
            Button newButton = new Button(myContext);

            Intent gotoEditActivity = new Intent(myContext, EditActivity.class);
            gotoEditActivity.putExtra("buttonIndex", buttonIndex);

            newButton.setOnClickListener(view -> {
                System.out.println("Stared edit activity");
                myContext.startActivity(gotoEditActivity);
            });

            newButton.setLayoutParams(new ViewGroup.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

            newButton.setText("Product Name: " + listElement.name + "\r\nPrice: " + listElement.price + "\r\nDescription: " + listElement.description);
            System.out.println("Button text: " + newButton.getText().toString());

            buttonLayout.addView(newButton);
            buttonIndex++;
        }
    }
}