package com.example.asynchronousjasondatareaderandwriter;

public class ListElement {
    public String name;
    public String price;
    public String description;

    ListElement(String inName, String inPrice, String inDescription) {
        name = inName;
        price = inPrice;
        description = inDescription;

    }
}
