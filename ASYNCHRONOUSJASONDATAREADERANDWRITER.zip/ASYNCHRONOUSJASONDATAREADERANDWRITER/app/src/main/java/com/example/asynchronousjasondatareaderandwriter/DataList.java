package com.example.asynchronousjasondatareaderandwriter;

import android.widget.Button;

import java.util.ArrayList;

public class DataList {
    static ArrayList<ListElement> listElements = new ArrayList<>();

    public static void addElement(String name, String price, String description) {
        listElements.add(new ListElement(name, price, description));
    }
    public static void removeElement(int index) {
        listElements.remove(index);
    }

    public static void editElement(int index, String name, String price, String description) {
        ListElement toEdit = listElements.get(index);
        if (toEdit != null) {
            toEdit.name = name;
            toEdit.price = price;
            toEdit.description = description;
        }
    }

}
