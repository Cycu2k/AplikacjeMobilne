package com.example.asynchronousjasondatareaderandwriter;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText inputProductName = findViewById(R.id.inputEditProductName);
        EditText inputPrice = findViewById(R.id.inputEditPrice);
        EditText inputDescription = findViewById(R.id.inputEditDescription);


        Button buttonSaveEdit = findViewById(R.id.buttonSaveEdit);
        Button buttonDeleteElement = findViewById(R.id.buttonDeleteElement);

        Intent intent = getIntent();
        // -1 is default if it cant find the variable
        int buttonIndex = intent.getIntExtra("buttonIndex", -1);

        buttonSaveEdit.setOnClickListener(view->{
            String productName = inputProductName.getText().toString();
            String price = inputPrice.getText().toString();
            String description = inputDescription.getText().toString();

            // save changes to list
            if (buttonIndex != -1) {
                DataList.editElement(buttonIndex, productName, price, description);
            } else {
                System.out.println("buttonIndex was -1 when editing the button???");
            }


            // clear data before exit
            inputProductName.setText("");
            inputProductName.setText("");
            inputDescription.setText("");


            // leave
            finish();
        });

        buttonDeleteElement.setOnClickListener(view->{
            // delete this record from the liiiiiiiist :O
            if (buttonIndex != -1) {
                DataList.removeElement(buttonIndex);
            }

            // exit
            finish();
        });



    }
}