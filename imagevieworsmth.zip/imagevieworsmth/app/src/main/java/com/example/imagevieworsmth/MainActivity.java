package com.example.imagevieworsmth;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // wyswietl info o rozmiarze imageview
        // wyswietl info o rozmiarze bitmapy zdjecia
        // zakomentowany kod nie jest czesia zadania 🤙🤙🤙🤙🤙🤙

        Button imageInfoButton = findViewById(R.id.imageInfoButton);
        TextView imageInfoText = findViewById(R.id.imageInfoText);
        ImageView imageView = findViewById(R.id.imageView);


        imageInfoButton.setOnClickListener((view)->{

            //Intent getImageIntent = new Intent(Intent.ACTION_PICK);
            //getImageIntent.setType("image/*");
            //startActivityForResult(getImageIntent, 127);



            // GET BITMAP TO CANVAS

            //try {
                Bitmap imageBitmap = ((imageView.getDrawable()) != null ? ((BitmapDrawable)imageView.getDrawable()).getBitmap() : null);
                imageInfoText.setText("Image view size: h:" + imageView.getHeight() + "; w: " + imageView.getWidth() + (imageBitmap != null ? " ///// Bitmap size: h:" + imageBitmap.getHeight() + "; w: " + imageBitmap.getWidth() : " ///// Bitmap size: NULL, NaN, NIL, nope, doesn't exist."));

                Bitmap mutableBitmap = imageBitmap.copy(Bitmap.Config.ARGB_8888, true);

                if (mutableBitmap == null) {
                    System.out.println("////////////////////////////// MUTABLE BITMAP IS NULLLLLLLLLLLLLLLLLLLLLLLL");
                } else {
                    System.out.println("////////////////////////////// Mutable bitmap is reaaaaal");
                }

                Paint paint = new Paint();
                paint.setARGB(255, 0, 0, 0);

                for (int i = 0; i < mutableBitmap.getWidth(); i++) {
                    for (int j = 0; j < mutableBitmap.getHeight(); j++) {
                        int oldColor = mutableBitmap.getPixel(i, j);
                        mutableBitmap.setPixel(i, j, oldColor + 500);
                    }
                }

                imageView.setImageBitmap(mutableBitmap);



            //} catch (Exception e){
            //    System.out.println("error_msg" + e);
            //    System.out.println(">>>>>>>>>>>>>>>>>" + e);
            //}



        });
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 127 && resultCode == RESULT_OK) {
            if (data == null) {
                System.out.println("RESULT DATA IS NULL");
                return;
            }

            Uri pickedImage = data.getData();

            String[] filePath = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(pickedImage, filePath, null, null, null);
            cursor.moveToFirst();
            String imagePath = cursor.getString(cursor.getColumnIndex(filePath[0]));
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;

            Bitmap bitmap = BitmapFactory.decodeFile(imagePath, options);
            // do stuff with my bitmap

            cursor.close();
        }




    }*/



}