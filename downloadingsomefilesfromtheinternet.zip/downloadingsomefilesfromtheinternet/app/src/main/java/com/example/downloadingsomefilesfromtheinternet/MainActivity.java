package com.example.downloadingsomefilesfromtheinternet;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

// http://klasy.itmargen.com/Rok%202024_2025/5TR/AM/Pobieranie%20danych%20z%20Internetu/Zadanie.txt
// http://klasy.itmargen.com/Rok%202024_2025/5TR/AM/Pobieranie%20danych%20z%20Internetu/Kod.txt

// https://square.github.io/retrofit/

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // pobierz dane z http://json.itmargen.com/5TR/

        // interpretuj na json

        // obsluz bledy polaczenia, odpowiedzi serwera, etc

        // wyswietl jako elementy listy

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://json.itmargen.com/").addConverterFactory(GsonConverterFactory.create()).build();

        JsonInterface jsonInterface = retrofit.create(JsonInterface.class);

        Call<List<MessageData>> data = jsonInterface.getMessageData();
        System.out.println("/////////////// PRINTED DATA //////////////");
        System.out.println(data);

       
    }
}

interface JsonInterface {
    @GET("5TR")
    Call<List<MessageData>> getMessageData();
}

class MessageData {
    String title;
    String description;
    String date;
    String author;
    String content;
}